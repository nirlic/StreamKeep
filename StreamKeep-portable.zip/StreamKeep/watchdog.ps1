# ============================================================
#  StreamKeep — watchdog.ps1
#  Monitors stream-watcher.ps1 and restarts it if it crashes
#
#  Created by Nirlicnick
# ============================================================

$ScriptDir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$ScriptPath  = "$ScriptDir\stream-watcher.ps1"
$LogFile     = "$ScriptDir\StreamBackups\streamkeep.log"
$RestartDelay = 30

function Write-WatchdogLog($msg) {
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [WATCHDOG] $msg"
    Write-Host $line -ForegroundColor Magenta
    try { Add-Content -Path $LogFile -Value $line -ErrorAction SilentlyContinue } catch {}
}

New-Item -ItemType Directory -Force -Path (Split-Path $LogFile) | Out-Null

Write-WatchdogLog "StreamKeep Watchdog started."
Write-WatchdogLog "Monitoring: $ScriptPath"

while ($true) {
    Write-WatchdogLog "Starting stream-watcher..."
    try {
        $proc = Start-Process powershell -ArgumentList "-ExecutionPolicy Bypass -File `"$ScriptPath`"" -PassThru -NoNewWindow
        $proc.WaitForExit()
        Write-WatchdogLog "stream-watcher exited (code $($proc.ExitCode)). Restarting in ${RestartDelay}s..."
    } catch {
        Write-WatchdogLog "Failed to start stream-watcher: $_. Retrying in ${RestartDelay}s..."
    }
    Start-Sleep -Seconds $RestartDelay
}
